
import { MenuItem, Testimonial } from './types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 't1',
    name: 'Al Pastor Supreme',
    description: 'لحم مفروم متبل مع الأناناس والكزبرة والبصل الأحمر في خبز التاكو التقليدي.',
    price: 850,
    category: 'Tacos',
    image: 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?auto=format&fit=crop&q=80&w=800',
    popular: true
  },
  {
    id: 'p1',
    name: 'Truffle Mushroom Pizza',
    description: 'فطر بري، زيت الترافل، جبنة الموزاريلا والزعتر الطازج.',
    price: 1200,
    category: 'Pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    popular: true
  },
  {
    id: 'b1',
    name: 'Wagyu Beef Burger',
    description: 'لحم واغيو 100%، بصل مكرمل، جبنة غرويير وخبز البريوش.',
    price: 1450,
    category: 'Burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800',
    popular: true
  },
  {
    id: 's1',
    name: 'Gourmet Cubano',
    description: 'لحم مشوي ببطء، جبن سويسري، مخلل وخردل في خبز مقرمش.',
    price: 950,
    category: 'Sandwiches',
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'si1',
    name: 'Truffle Parmesan Fries',
    description: 'بطاطس مقلية طازجة مع زيت الترافل وجبنة البارميزان.',
    price: 450,
    category: 'Sides',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=800'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'ياسين بن علي',
    role: 'ناقد طعام',
    content: "أفضل برجر ذقته في الجزائر العاصمة، الجودة عالمية والخدمة سريعة.",
    rating: 5,
    avatar: 'https://i.pravatar.cc/150?u=yacine'
  }
];

export const CONTACT_INFO = {
  phone: '0550 12 34 56',
  whatsapp: '213550123456',
  address: 'حي سعيد حمدين، الجزائر العاصمة',
  email: 'contact@biteandsizzle.dz',
  hours: {
    weekdays: '11:00 - 23:00',
    weekends: '11:00 - 01:00'
  }
};

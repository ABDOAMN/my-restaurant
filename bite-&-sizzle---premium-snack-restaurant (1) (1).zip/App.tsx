
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MenuSection from './components/MenuSection';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';
import Testimonials from './components/Testimonials';
import FoodAssistant from './components/FoodAssistant';
import Footer from './components/Footer';
import CartModal from './components/CartModal';
import AuthModal from './components/AuthModal';
import AdminPanel from './components/AdminPanel';
import { MenuItem, CartItem, User } from './types';
import { storageService } from './services/storageService';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);

  useEffect(() => {
    const user = storageService.getCurrentUser();
    if (user) setCurrentUser(user);
    
    const handleScroll = () => {
      const sections = ['home', 'menu', 'about', 'contact'];
      const scrollPosition = window.scrollY + 100;
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          if (scrollPosition >= element.offsetTop && scrollPosition < element.offsetTop + element.offsetHeight) {
            setActiveSection(section);
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const handleLogout = () => {
    storageService.setCurrentUser(null);
    setCurrentUser(null);
    setShowAdmin(false);
  };

  return (
    <div className="relative overflow-hidden bg-slate-950 min-h-screen">
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-600/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-red-600/10 rounded-full blur-[120px] pointer-events-none"></div>

      <Navbar 
        activeSection={activeSection} 
        cartCount={cart.reduce((s, i) => s + i.quantity, 0)} 
        onOpenCart={() => setIsCartOpen(true)} 
        onOpenAuth={() => setIsAuthOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        onToggleAdmin={() => setShowAdmin(!showAdmin)}
        isAdminView={showAdmin}
      />
      
      <main>
        {showAdmin && currentUser?.isAdmin ? (
          <AdminPanel />
        ) : (
          <>
            <section id="home"><Hero /></section>
            <section id="menu" className="py-20"><MenuSection onAddToCart={addToCart} /></section>
            <section id="about" className="py-20 bg-slate-900/50"><AboutSection /></section>
            <section id="testimonials" className="py-20"><Testimonials /></section>
            <section id="contact" className="py-20"><ContactSection /></section>
          </>
        )}
      </main>

      {!showAdmin && <Footer />}
      <FoodAssistant />
      
      <CartModal 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        cart={cart}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
        currentUser={currentUser}
        onAuthRequired={() => setIsAuthOpen(true)}
        onClearCart={() => setCart([])}
      />

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        onLogin={(user) => setCurrentUser(user)} 
      />
    </div>
  );
};

export default App;

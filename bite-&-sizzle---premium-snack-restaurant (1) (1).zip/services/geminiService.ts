
import { GoogleGenAI, Type } from "@google/genai";
import { MENU_ITEMS } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getFoodRecommendation = async (userMood: string) => {
  try {
    const menuContext = MENU_ITEMS.map(item => `${item.name} (${item.category}): ${item.description}`).join('\n');
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a friendly waiter at Bite & Sizzle. Based on the user's mood/preference: "${userMood}", recommend 1-2 items from our menu below. Keep it concise, appetizing, and friendly.
      
      Menu:
      ${menuContext}`,
      config: {
        maxOutputTokens: 250,
        temperature: 0.7,
      },
    });

    return response.text || "I'm sorry, I'm having a bit of trouble thinking right now. How about our Wagyu Beef Burger? It's always a hit!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Our Chef suggests the Wagyu Beef Burger for a premium experience today!";
  }
};

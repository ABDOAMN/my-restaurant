
import React, { useState } from 'react';
import { MENU_ITEMS } from '../constants';
import { Category, MenuItem } from '../types';
import { Plus, ShoppingCart } from 'lucide-react';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem) => void;
}

const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState<Category>('All');
  const categories: Category[] = ['All', 'Tacos', 'Pizza', 'Burgers', 'Sandwiches', 'Sides', 'Drinks'];
  const filteredItems = activeCategory === 'All' ? MENU_ITEMS : MENU_ITEMS.filter(i => i.category === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-sm font-bold text-orange-500 uppercase tracking-[0.2em] mb-4">قائمة المأكولات</h2>
        <h3 className="text-4xl md:text-6xl font-black font-display text-white mb-8 italic">استمتع بأشهى المذاقات</h3>
        <div className="flex flex-wrap justify-center gap-3">
          {categories.map((cat) => (
            <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-6 py-2 rounded-full text-sm font-bold transition-all border ${activeCategory === cat ? 'bg-orange-600 border-orange-600 text-white shadow-lg' : 'bg-transparent border-slate-800 text-slate-400 hover:text-orange-400'}`}>
              {cat === 'All' ? 'الكل' : cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {filteredItems.map((item) => (
          <div key={item.id} className="group bg-slate-900/40 rounded-3xl overflow-hidden border border-slate-800/50 hover:border-orange-500/30 transition-all hover:shadow-2xl">
            <div className="h-56 relative overflow-hidden">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                <button 
                  onClick={() => onAddToCart(item)}
                  className="w-full py-3 bg-white text-slate-950 rounded-xl font-bold text-sm transform translate-y-4 group-hover:translate-y-0 transition-transform flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={16} /> أضف للطلب
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-bold text-lg text-white group-hover:text-orange-400 transition-colors">{item.name}</h4>
                <span className="text-orange-500 font-black text-lg whitespace-nowrap">{item.price} DA</span>
              </div>
              <p className="text-slate-500 text-sm mb-4 line-clamp-2">{item.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">{item.category}</span>
                <button onClick={() => onAddToCart(item)} className="p-2 bg-slate-800 rounded-lg text-white hover:bg-orange-600 transition-colors">
                  <Plus size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MenuSection;

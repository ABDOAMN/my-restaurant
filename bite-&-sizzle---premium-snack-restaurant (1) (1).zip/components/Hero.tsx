
import React from 'react';
import { ArrowRight, Utensils } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-screen flex items-center justify-center pt-20 px-6 overflow-hidden">
      {/* Background Media */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=2000" 
          alt="Gourmet Food" 
          className="w-full h-full object-cover scale-110 opacity-60"
        />
      </div>

      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center relative z-20">
        <div className="space-y-8 text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-600/20 border border-orange-500/30 text-orange-400 text-xs font-bold uppercase tracking-widest">
            <Utensils size={14} /> The Ultimate Flavor Destination
          </div>
          
          <h1 className="text-5xl lg:text-7xl xl:text-8xl font-black leading-[0.9] font-display">
            FRESH <span className="text-orange-500">TACOS</span> <br /> 
            & <span className="italic text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-400">PIZZA</span> <br />
            MADE WITH PASSION
          </h1>

          <p className="text-slate-400 text-lg max-w-lg leading-relaxed">
            Experience the art of gourmet snacks. From flame-grilled burgers to hand-stretched pizzas, we use only the finest local ingredients for your daily cravings.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center md:justify-start">
            <a 
              href="#menu" 
              className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-full font-bold flex items-center gap-2 transition-all shadow-xl shadow-orange-950/40 hover:-translate-y-1"
            >
              Explore Menu <ArrowRight size={20} />
            </a>
            <a 
              href="#about" 
              className="px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-full font-bold transition-all"
            >
              Our Story
            </a>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-8 pt-6">
            <div className="text-center md:text-left">
              <div className="text-2xl font-bold text-white">4.9/5</div>
              <div className="text-xs text-slate-500 uppercase font-bold tracking-widest">Customer Rating</div>
            </div>
            <div className="w-px h-8 bg-slate-800"></div>
            <div className="text-center md:text-left">
              <div className="text-2xl font-bold text-white">15m</div>
              <div className="text-xs text-slate-500 uppercase font-bold tracking-widest">Avg Delivery</div>
            </div>
            <div className="w-px h-8 bg-slate-800"></div>
            <div className="text-center md:text-left">
              <div className="text-2xl font-bold text-white">100%</div>
              <div className="text-xs text-slate-500 uppercase font-bold tracking-widest">Fresh Quality</div>
            </div>
          </div>
        </div>

        {/* Floating Dish Visuals */}
        <div className="relative hidden lg:block">
           <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-500/10 rounded-full blur-[100px]"></div>
           <div className="relative z-10 p-12">
              <img 
                src="https://images.unsplash.com/photo-1565299507177-b0ac66763828?auto=format&fit=crop&q=80&w=1000" 
                alt="Signature Dish" 
                className="rounded-[40px] shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-700 border-4 border-slate-900"
              />
              <div className="absolute -bottom-4 -left-4 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-2xl animate-bounce-slow">
                <div className="text-orange-500 font-black text-2xl leading-none">HOT & FRESH</div>
                <div className="text-slate-400 text-xs mt-1 uppercase tracking-widest">Served every 5 mins</div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;

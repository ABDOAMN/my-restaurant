
import React, { useState, useEffect } from 'react';
import { X, Trash2, ShoppingBag, Send, CheckCircle2 } from 'lucide-react';
import { CartItem, ALGERIAN_WILAYAS, Order, User } from '../types';
import { storageService } from '../services/storageService';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeFromCart: (id: string) => void;
  currentUser: User | null;
  onAuthRequired: () => void;
  onClearCart: () => void;
}

const CartModal: React.FC<CartModalProps> = ({ isOpen, onClose, cart, updateQuantity, removeFromCart, currentUser, onAuthRequired, onClearCart }) => {
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    wilaya: '16- Alger',
    address: ''
  });

  useEffect(() => {
    if (currentUser) {
      setFormData(prev => ({
        ...prev,
        name: currentUser.name,
        phone: currentUser.phone || '',
        wilaya: currentUser.wilaya || '16- Alger',
        address: currentUser.address || ''
      }));
    }
  }, [currentUser]);

  // Reset success state when opening modal
  useEffect(() => {
    if (isOpen) setIsSuccess(false);
  }, [isOpen]);

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleSendOrder = () => {
    if (!currentUser) {
      onAuthRequired();
      return;
    }

    const newOrder: Order = {
      id: `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      userId: currentUser.id,
      userName: formData.name,
      userPhone: formData.phone,
      wilaya: formData.wilaya,
      address: formData.address,
      items: cart,
      total: total,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    // Save to Local Database only (No WhatsApp)
    storageService.saveOrder(newOrder);

    // Show Success UI
    setIsSuccess(true);
    onClearCart();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-slate-900 w-full max-w-2xl h-[90vh] sm:h-auto sm:max-h-[85vh] rounded-t-[32px] sm:rounded-[32px] shadow-2xl flex flex-col overflow-hidden border border-slate-800 transition-all duration-500">
        
        {/* Success View */}
        {isSuccess ? (
          <div className="flex flex-col items-center justify-center p-12 text-center h-full space-y-6">
            <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center text-green-500 animate-bounce">
              <CheckCircle2 size={64} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-white italic mb-2 tracking-tighter uppercase">تم استلام طلبك!</h2>
              <p className="text-slate-400 max-w-sm mx-auto">
                شكراً لك {formData.name}. لقد تم تسجيل طلبك بنجاح في نظامنا. سيقوم فريقنا بمراجعته والاتصال بك قريباً لتأكيد التوصيل.
              </p>
            </div>
            <button 
              onClick={onClose}
              className="px-12 py-4 bg-orange-600 hover:bg-orange-700 text-white font-black rounded-2xl shadow-xl transition-all active:scale-95"
            >
              العودة للمتجر
            </button>
          </div>
        ) : (
          <>
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
              <div className="flex items-center gap-3">
                <ShoppingBag className="text-orange-500" />
                <h2 className="text-xl font-black uppercase tracking-tight">سلة الطلبات</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {cart.length === 0 ? (
                <div className="text-center py-20">
                  <div className="text-slate-600 mb-4 flex justify-center"><ShoppingBag size={64} /></div>
                  <p className="text-slate-400 font-bold text-lg">السلة فارغة حالياً</p>
                  <button onClick={onClose} className="mt-4 text-orange-500 font-bold uppercase text-sm tracking-widest">اكتشف المنيو</button>
                </div>
              ) : (
                <>
                  <div className="space-y-4">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center gap-4 bg-slate-950/40 p-4 rounded-2xl border border-slate-800">
                        <img src={item.image} className="w-20 h-20 object-cover rounded-xl" alt={item.name} />
                        <div className="flex-1">
                          <h4 className="font-bold text-white">{item.name}</h4>
                          <p className="text-orange-500 font-black">{item.price} DA</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-xl font-bold">-</button>
                          <span className="font-bold w-4 text-center">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-xl font-bold">+</button>
                          <button onClick={() => removeFromCart(item.id)} className="ml-2 text-slate-600 hover:text-red-500 transition-colors">
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-6 pt-6 border-t border-slate-800">
                    <h3 className="font-black text-white text-lg flex items-center gap-2">
                      <span className="w-2 h-6 bg-orange-600 rounded-full"></span> معلومات التوصيل
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">الاسم الكامل</label>
                        <input 
                          type="text" 
                          placeholder="محمد علي"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-600 outline-none"
                          value={formData.name}
                          onChange={e => setFormData({...formData, name: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">رقم الهاتف</label>
                        <input 
                          type="tel" 
                          placeholder="05 / 06 / 07 ..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-600 outline-none"
                          value={formData.phone}
                          onChange={e => setFormData({...formData, phone: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">الولاية</label>
                        <select 
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-600 outline-none"
                          value={formData.wilaya}
                          onChange={e => setFormData({...formData, wilaya: e.target.value})}
                        >
                          {ALGERIAN_WILAYAS.map(w => <option key={w} value={w}>{w}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">العنوان بالتفصيل</label>
                        <input 
                          type="text" 
                          placeholder="رقم المنزل، اسم الشارع..."
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-600 outline-none"
                          value={formData.address}
                          onChange={e => setFormData({...formData, address: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 bg-slate-950 border-t border-slate-800">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-slate-400 font-bold">المجموع الكلي:</span>
                  <span className="text-3xl font-black text-orange-500">{total} DA</span>
                </div>
                {!currentUser ? (
                  <button 
                    onClick={onAuthRequired}
                    className="w-full bg-white text-slate-950 font-black py-4 rounded-2xl flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95"
                  >
                    Veuillez vous connecter pour commander
                  </button>
                ) : (
                  <button 
                    onClick={handleSendOrder}
                    disabled={!formData.name || !formData.phone}
                    className="w-full bg-orange-600 hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95"
                  >
                    تأكيد وإرسال الطلب <Send size={20} />
                  </button>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default CartModal;

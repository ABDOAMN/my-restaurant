
import React from 'react';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const ContactSection: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid lg:grid-cols-2 gap-16">
        <div className="space-y-12">
          <div>
            <h2 className="text-sm font-bold text-orange-500 uppercase tracking-[0.2em] mb-4">Get In Touch</h2>
            <h3 className="text-4xl md:text-6xl font-black font-display text-white mb-6 leading-tight italic">Visit Our Store Or <br /><span className="text-orange-500 underline decoration-slate-800">Say Hello!</span></h3>
            <p className="text-slate-500 text-lg">Whether you have a question, need catering, or just want to tell us how much you loved the tacos - we're here for you.</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-4 text-white">
                <div className="p-3 bg-orange-600/10 rounded-xl text-orange-500"><Phone size={24} /></div>
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest">Call Us</div>
                  <div className="font-bold">{CONTACT_INFO.phone}</div>
                </div>
              </div>
              <div className="flex items-center gap-4 text-white">
                <div className="p-3 bg-orange-600/10 rounded-xl text-orange-500"><Mail size={24} /></div>
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest">Email Us</div>
                  <div className="font-bold">{CONTACT_INFO.email}</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-4 text-white">
                <div className="p-3 bg-orange-600/10 rounded-xl text-orange-500"><MapPin size={24} /></div>
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest">Location</div>
                  <div className="font-bold text-sm leading-tight">{CONTACT_INFO.address}</div>
                </div>
              </div>
              <div className="flex items-center gap-4 text-white">
                <div className="p-3 bg-orange-600/10 rounded-xl text-orange-500"><Clock size={24} /></div>
                <div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest">Opening Hours</div>
                  <div className="font-bold text-xs">Mon-Fri: {CONTACT_INFO.hours.weekdays}</div>
                  <div className="font-bold text-xs">Sat-Sun: {CONTACT_INFO.hours.weekends}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-[40px] overflow-hidden grayscale contrast-125 border border-slate-800 h-64 relative">
             <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover opacity-50" alt="Map Placeholder" />
             <div className="absolute inset-0 flex items-center justify-center">
                <a href="#" className="bg-white text-slate-950 px-6 py-3 rounded-full font-bold shadow-xl hover:-translate-y-1 transition-transform">Get Directions</a>
             </div>
          </div>
        </div>

        <div className="bg-slate-900/50 p-8 md:p-12 rounded-[50px] border border-slate-800 shadow-2xl">
          <h4 className="text-2xl font-bold text-white mb-8">Send A Message</h4>
          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Full Name</label>
                <input type="text" placeholder="John Doe" className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-orange-600 transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Email Address</label>
                <input type="email" placeholder="john@example.com" className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-orange-600 transition-colors" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Subject</label>
              <select className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-orange-600 transition-colors">
                <option>General Inquiry</option>
                <option>Table Reservation</option>
                <option>Catering Event</option>
                <option>Feedback</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-2">Your Message</label>
              <textarea placeholder="Tell us something..." rows={5} className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-orange-600 transition-colors resize-none"></textarea>
            </div>
            <button className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-3 shadow-lg shadow-orange-950/20 active:scale-95 transition-all">
              Send Message <Send size={20} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;


import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storageService';
import { Order, OrderStatus } from '../types';
import { Check, X, Clock, Package, Filter, User as UserIcon } from 'lucide-react';

const AdminPanel: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all');

  useEffect(() => {
    setOrders(storageService.getOrders());
  }, []);

  const handleStatusUpdate = (orderId: string, status: OrderStatus) => {
    storageService.updateOrderStatus(orderId, status);
    setOrders(storageService.getOrders());
  };

  const filteredOrders = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  return (
    <div className="max-w-7xl mx-auto px-6 pt-32 pb-20 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h2 className="text-sm font-bold text-orange-500 uppercase tracking-[0.2em] mb-2">Tableau de Bord</h2>
          <h1 className="text-4xl font-black font-display text-white">Gestion des Commandes</h1>
        </div>

        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          {(['all', 'pending', 'accepted', 'refused'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all ${filter === f ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
            >
              {f === 'all' ? 'Tous' : f === 'pending' ? 'En attente' : f === 'accepted' ? 'Acceptés' : 'Refusés'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6">
        {filteredOrders.length === 0 ? (
          <div className="bg-slate-900/50 rounded-[40px] p-20 text-center border border-slate-800 border-dashed">
            <Package className="mx-auto text-slate-800 mb-4" size={64} />
            <p className="text-slate-500 font-bold">Aucune commande trouvée</p>
          </div>
        ) : (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-slate-900/50 border border-slate-800 rounded-[32px] overflow-hidden hover:border-slate-700 transition-colors">
              <div className="p-8">
                <div className="flex flex-col lg:flex-row justify-between gap-8">
                  {/* Left: User Info */}
                  <div className="flex-1 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-orange-600/10 flex items-center justify-center text-orange-500">
                        <UserIcon size={24} />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white">{order.userName}</h3>
                        <p className="text-slate-500 text-sm">{order.userPhone} • {order.wilaya}</p>
                      </div>
                    </div>
                    <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800 text-sm text-slate-300">
                      <strong>Adresse:</strong> {order.address}
                    </div>
                  </div>

                  {/* Middle: Order Items */}
                  <div className="flex-[2] space-y-4">
                    <div className="text-xs font-black uppercase text-slate-500 tracking-widest mb-2">Détails de la commande</div>
                    <div className="grid sm:grid-cols-2 gap-3">
                      {order.items.map(item => (
                        <div key={item.id} className="flex justify-between items-center text-sm p-3 bg-slate-950/30 rounded-xl border border-slate-800/50">
                          <span className="text-slate-300">
                            <span className="text-orange-500 font-bold">x{item.quantity}</span> {item.name}
                          </span>
                          <span className="text-white font-black">{item.price * item.quantity} DA</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex-1 flex flex-col justify-between items-end gap-6 border-t lg:border-t-0 lg:border-l border-slate-800 lg:pl-8 pt-6 lg:pt-0">
                    <div className="text-right">
                      <div className="text-xs font-black uppercase text-slate-500 tracking-widest mb-1">Total à payer</div>
                      <div className="text-3xl font-black text-orange-500">{order.total} DA</div>
                      <div className="text-[10px] text-slate-600 mt-1">{new Date(order.createdAt).toLocaleString()}</div>
                    </div>

                    <div className="flex gap-2 w-full">
                      {order.status === 'pending' ? (
                        <>
                          <button 
                            onClick={() => handleStatusUpdate(order.id, 'refused')}
                            className="flex-1 py-3 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all font-bold text-sm flex items-center justify-center gap-2"
                          >
                            <X size={16} /> Refuser
                          </button>
                          <button 
                            onClick={() => handleStatusUpdate(order.id, 'accepted')}
                            className="flex-1 py-3 rounded-xl bg-green-500/10 text-green-500 hover:bg-green-500 hover:text-white transition-all font-bold text-sm flex items-center justify-center gap-2"
                          >
                            <Check size={16} /> Accepter
                          </button>
                        </>
                      ) : (
                        <div className={`w-full py-3 rounded-xl text-center font-bold text-sm uppercase tracking-widest flex items-center justify-center gap-2 ${order.status === 'accepted' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                          {order.status === 'accepted' ? <Check size={16} /> : <X size={16} />}
                          {order.status === 'accepted' ? 'Commande Acceptée' : 'Commande Refusée'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminPanel;

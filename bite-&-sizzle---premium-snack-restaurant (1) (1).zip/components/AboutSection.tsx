
import React from 'react';
import { ShieldCheck, Truck, UtensilsCrossed, Clock } from 'lucide-react';

const AboutSection: React.FC = () => {
  const features = [
    { icon: <ShieldCheck className="text-orange-500" />, title: "Quality First", desc: "We source only premium organic ingredients from local farms." },
    { icon: <Clock className="text-orange-500" />, title: "Fast Service", desc: "Your meal prepared and ready within 15 minutes of ordering." },
    { icon: <Truck className="text-orange-500" />, title: "City-wide Delivery", desc: "Safe and hygienic delivery to your doorstep, anywhere in town." },
    { icon: <UtensilsCrossed className="text-orange-500" />, title: "Chef-Driven", desc: "Our menu is curated by award-winning chefs who love comfort food." },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-orange-600/20 rounded-full blur-[80px]"></div>
          <img 
            src="https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=1000" 
            alt="Chef Cooking" 
            className="rounded-[60px] relative z-10 shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
          />
          <div className="absolute -bottom-8 -right-8 bg-orange-600 text-white p-10 rounded-[40px] z-20 shadow-2xl hidden md:block">
            <div className="text-6xl font-black font-display italic">12+</div>
            <div className="text-sm font-bold uppercase tracking-widest">Years of Sizzling</div>
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <h2 className="text-sm font-bold text-orange-500 uppercase tracking-[0.2em] mb-4">Our Story</h2>
            <h3 className="text-4xl md:text-6xl font-black font-display text-white leading-tight">
              Where Every Bite <br /><span className="text-orange-500">Tells A Tale</span>
            </h3>
          </div>
          
          <p className="text-slate-400 text-lg leading-relaxed">
            Founded in 2012, Bite & Sizzle started as a humble food truck with a simple mission: to serve the best gourmet snacks without the pretentiousness. Today, we've evolved into a local icon, blending traditional cooking techniques with modern flavor profiles.
          </p>

          <div className="grid sm:grid-cols-2 gap-6">
            {features.map((f, i) => (
              <div key={i} className="flex gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                <div className="mt-1">{f.icon}</div>
                <div>
                  <h4 className="font-bold text-white mb-1">{f.title}</h4>
                  <p className="text-slate-500 text-xs leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;


import React from 'react';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 pt-20 pb-10 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="md:col-span-2 space-y-6">
            <a href="#" className="text-3xl font-black text-orange-500 tracking-tighter uppercase italic">Bite <span className="text-white">&</span> Sizzle</a>
            <p className="text-slate-500 text-lg max-w-sm leading-relaxed">
              We're redefining the gourmet snack experience, one sizzle at a time. Quality ingredients, expert chefs, and lightning fast service.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:border-orange-500 transition-all">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Quick Links</h5>
            <ul className="space-y-4">
              {['Home', 'Our Menu', 'About Us', 'Contact', 'Reservations'].map((item) => (
                <li key={item}>
                  <a href={`#${item.toLowerCase().replace(' ', '')}`} className="text-slate-500 hover:text-orange-500 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Legal</h5>
            <ul className="space-y-4">
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'Accessibility'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-orange-500 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-slate-900 flex flex-col md:row items-center justify-between gap-6">
          <p className="text-slate-600 text-sm">
            © {new Date().getFullYear()} Bite & Sizzle. All rights reserved. Crafted for food lovers.
          </p>
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-slate-600 text-xs font-bold uppercase tracking-widest">Kitchen Status: OPEN</span>
             </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, ShoppingCart, User as UserIcon, LogOut, Settings } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  activeSection: string;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  currentUser: User | null;
  onLogout: () => void;
  onToggleAdmin: () => void;
  isAdminView: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ 
  activeSection, 
  cartCount, 
  onOpenCart, 
  onOpenAuth, 
  currentUser, 
  onLogout,
  onToggleAdmin,
  isAdminView
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 ${scrolled ? 'bg-slate-950/90 backdrop-blur-md py-4 border-b border-slate-800 shadow-xl' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#home" className="text-2xl font-black text-orange-500 tracking-tighter italic">BITE & SIZZLE</a>

        <div className="hidden md:flex items-center gap-6">
          {!isAdminView && ['Home', 'Menu', 'About', 'Contact'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className={`text-xs font-black uppercase tracking-widest hover:text-orange-500 transition-colors ${activeSection === item.toLowerCase() ? 'text-orange-500' : 'text-slate-400'}`}>
              {item === 'Home' ? 'الرئيسية' : item === 'Menu' ? 'المنيو' : item === 'About' ? 'عن المطعم' : 'اتصل بنا'}
            </a>
          ))}
          
          <div className="w-px h-6 bg-slate-800 mx-2"></div>

          <button onClick={onOpenCart} className="relative p-2 text-slate-300 hover:text-orange-500 transition-colors">
            <ShoppingCart size={22} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </button>

          {currentUser ? (
            <div className="relative">
              <button 
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-1.5 pr-4 rounded-full hover:border-orange-500/50 transition-all"
              >
                <div className="w-8 h-8 rounded-full bg-orange-600 flex items-center justify-center text-white font-bold text-sm">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="text-sm font-bold text-white">{currentUser.name.split(' ')[0]}</span>
              </button>

              {showUserMenu && (
                <div className="absolute top-full mt-3 right-0 w-56 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 py-3 space-y-1">
                  {currentUser.isAdmin && (
                    <button 
                      onClick={() => { onToggleAdmin(); setShowUserMenu(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${isAdminView ? 'bg-orange-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                    >
                      <Settings size={18} /> {isAdminView ? 'Vue Boutique' : 'Admin Panel'}
                    </button>
                  )}
                  <button 
                    onClick={() => { onLogout(); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <LogOut size={18} /> Déconnexion
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button 
              onClick={onOpenAuth}
              className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors font-bold text-xs uppercase tracking-widest"
            >
              <UserIcon size={18} /> Se Connecter
            </button>
          )}

          {!isAdminView && (
            <a href="tel:0550123456" className="bg-orange-600 px-6 py-2.5 rounded-full text-white text-xs font-black uppercase flex items-center gap-2 hover:bg-orange-700 transition-all shadow-lg shadow-orange-950/20">
              <Phone size={14} /> 0550...
            </a>
          )}
        </div>

        <div className="flex items-center gap-4 md:hidden">
          <button onClick={onOpenCart} className="relative p-2 text-slate-100">
            <ShoppingCart size={24} />
            {cartCount > 0 && <span className="absolute -top-1 -right-1 bg-orange-600 text-[10px] w-4 h-4 rounded-full flex items-center justify-center">{cartCount}</span>}
          </button>
          <button onClick={() => setIsOpen(!isOpen)} className="text-slate-100">
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="fixed inset-0 bg-slate-950 z-[120] flex flex-col items-center justify-center gap-8 md:hidden">
          {currentUser?.isAdmin && (
            <button onClick={() => { onToggleAdmin(); setIsOpen(false); }} className="text-orange-500 font-black text-2xl uppercase italic underline">
              {isAdminView ? 'RETOUR BOUTIQUE' : 'ADMIN PANEL'}
            </button>
          )}
          {['الرئيسية', 'المنيو', 'عن المطعم', 'اتصل بنا'].map((item, i) => (
            <a key={i} href={`#${['home', 'menu', 'about', 'contact'][i]}`} onClick={() => setIsOpen(false)} className="text-3xl font-black text-white hover:text-orange-500">{item}</a>
          ))}
          {!currentUser ? (
            <button onClick={() => { onOpenAuth(); setIsOpen(false); }} className="text-2xl font-bold text-slate-400">CONNEXION</button>
          ) : (
            <button onClick={() => { onLogout(); setIsOpen(false); }} className="text-2xl font-bold text-red-500">DÉCONNEXION</button>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;

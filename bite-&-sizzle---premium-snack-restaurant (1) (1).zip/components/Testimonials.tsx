
import React from 'react';
import { TESTIMONIALS } from '../constants';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-sm font-bold text-orange-500 uppercase tracking-[0.2em] mb-4">Guest Reviews</h2>
        <h3 className="text-4xl md:text-5xl font-black font-display text-white italic">What Our Sizzlers Say</h3>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {TESTIMONIALS.map((t) => (
          <div key={t.id} className="bg-slate-900 p-10 rounded-[40px] border border-slate-800 relative group">
            <Quote size={60} className="absolute top-10 right-10 text-slate-800 group-hover:text-orange-500/10 transition-colors" />
            <div className="flex gap-1 mb-6">
              {[...Array(t.rating)].map((_, i) => (
                <Star key={i} size={16} fill="#f97316" className="text-orange-500" />
              ))}
            </div>
            <p className="text-slate-300 text-xl italic leading-relaxed mb-8 relative z-10">
              "{t.content}"
            </p>
            <div className="flex items-center gap-4">
              <img src={t.avatar} alt={t.name} className="w-14 h-14 rounded-full border-2 border-orange-500/30" />
              <div>
                <h4 className="text-white font-bold">{t.name}</h4>
                <p className="text-slate-500 text-sm font-semibold uppercase tracking-widest">{t.role}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;
